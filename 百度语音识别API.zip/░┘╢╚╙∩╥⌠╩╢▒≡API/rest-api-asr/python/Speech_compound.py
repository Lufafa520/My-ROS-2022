from aip import AipSpeech


class Aip_Speechsynthesis:
    
    def __init__(self):
        
        
        #语音合成 key
        self.APP_ID = "25511326"
        self.APP_KEY = "yjnO0wb1yUwzyPbEqY2OXw2r"
        self.SECRET_KEY = "phtam0war4FQYxWs14Cza2YrWTdPywIV"
        self.client = AipSpeech(self.APP_ID,self.APP_KEY,self.SECRET_KEY)
        
        

    def _document_write(self,text):

        result = self.client.synthesis(text,'zh',1,{
        'vol':15,'per':0,
        'pit':5,'spd':4})

        file_name = './demo01.wav'

        if not isinstance(result,dict):
            with open(file_name,'wb') as fp:
                fp.write(result)







Aip_Speechsynthesis()._document_write("我是智能机器人")
